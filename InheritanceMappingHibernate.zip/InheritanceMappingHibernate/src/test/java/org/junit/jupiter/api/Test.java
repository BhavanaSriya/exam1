package org.junit.jupiter.api;

public class Test {

}
