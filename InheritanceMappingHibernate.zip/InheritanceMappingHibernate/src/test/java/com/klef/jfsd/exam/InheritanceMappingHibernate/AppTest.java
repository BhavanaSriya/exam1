package com.klef.jfsd.exam.InheritanceMappingHibernate;

import org.junit.jupiter.api.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {

    /**
     * Rigorous Test :-)
     */
    
    public void testApp() {
        assertTrue(true);
    }

	private void assertTrue(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
